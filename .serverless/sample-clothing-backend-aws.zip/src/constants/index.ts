export const SIZES_ORDER = [
  "26",
  "28",
  "30",
  "32",
  "xs",
  "s",
  "m",
  "l",
  "xl",
  "2xl",
];
